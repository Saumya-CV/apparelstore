package com.parallelvirtual;

import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObjects;
import com.testcases.ExcelUtils;

public class VMs {
	
	public static RemoteWebDriver d1;
	
	@Test	
	public void Testcase1() throws Exception {
		String URL = "http://192.168.68.109:4444/wd/hub";
		DesiredCapabilities capability = DesiredCapabilities.chrome();
		capability.setBrowserName("chrome");
		capability.setPlatform(Platform.WINDOWS);
		d1 = new RemoteWebDriver(new URL(URL),capability);
		System.setProperty("webdriver.chrome.driver","./Browser/Utils/chromedriver.exe");
		d1.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		d1.manage().window().maximize();
		ExcelUtils.setExcelFile("./Input/TestDataExample2.xlsx");
		String Email = ExcelUtils.getCellData("LoginID", 2, 0);
	
		LoginPageObjects lp = new LoginPageObjects(d1);
		LoginPageObjects.email.sendKeys(Email);
		String Psswd = ExcelUtils.getCellData("LoginID", 2, 1);
		LoginPageObjects.password.sendKeys(Psswd);
		LoginPageObjects.signin.click();
		
	}
	

}
