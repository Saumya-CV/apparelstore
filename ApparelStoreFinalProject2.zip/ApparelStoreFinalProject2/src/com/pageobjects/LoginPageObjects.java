package com.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageObjects {
	
	public static WebDriver d1;
	

	@FindBy(id="email")
	public static WebElement email;
	
	@FindBy(id="passwd")
	public static WebElement password;
	
	@FindBy(xpath="//button[@class='button btn btn-default button-medium']")
	public static WebElement signin;
	
	public LoginPageObjects (WebDriver d1)
	{
		LoginPageObjects.d1=d1;
		PageFactory.initElements(d1, this);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
