package com.testcases;


import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObjects;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ShareInFacebook {
	
public static WebDriver d1;
public static ExtentTest test;
public static ExtentReports report;



//Purpose of Test case :Share a selected item from site to Facebook
	
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
		report = new ExtentReports("./Reports/ShareInFacebook.html");
		test = report.startTest("ShareInFacebook");
	}
	
	@BeforeTest
		public static void LoginValidID() throws Exception
	{
		d1.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		d1.manage().window().maximize();
	
		ExcelUtils.setExcelFile("./Input/TestDataExample2.xlsx");
		String Email = ExcelUtils.getCellData("LoginID", 2, 0);
	
		LoginPageObjects lp = new LoginPageObjects(d1);
		LoginPageObjects.email.sendKeys(Email);
		String Psswd = ExcelUtils.getCellData("LoginID", 2, 1);
		LoginPageObjects.password.sendKeys(Psswd);
		LoginPageObjects.signin.click();
	}
	
	@Test
		public static void FacebookShare() throws IOException {
		d1.findElement(By.id("search_query_top")).sendKeys("Blouse");
		d1.findElement(By.xpath("//button[@class='btn btn-default button-search']")).click();
		d1.findElement(By.xpath("//a[@title='Blouse'][normalize-space()='Blouse']")).click();
		d1.findElement(By.xpath("//button[@class='btn btn-default btn-facebook']")).click();
		
	//Per instructions we are to open the Facebook page and then click on cancel at the bottom of the page.
		//There is no cancel button at the bottom of the page. See screenshot in folder.
		
		String parentWindowHandler = d1.getWindowHandle(); 
		String subWindowHandler = null;
		
		Set<String> handles = d1.getWindowHandles(); 
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();
		}
		d1.switchTo().window(subWindowHandler);
		
		if(d1.getTitle().equals("Facebook"))
		{
			test.log(LogStatus.PASS,"Facebook Share Successfully completed");
		}
		else
		{
			test.log(LogStatus.FAIL, "Test Failed");
		}
		File screenshot = ((TakesScreenshot)d1).getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(screenshot, new File("./Screenshots/screenshots.png"));
			
		System.out.println("Screenshot captured");
		String title = d1.getTitle();
		FileUtils.copyFile(screenshot, new File("./Screenshots/"+title+".png"));
		
	}
	@AfterTest
	public static void endTest() {
		report.endTest(test);
		report.flush();
	}
}

//Facebook share completed succesfully