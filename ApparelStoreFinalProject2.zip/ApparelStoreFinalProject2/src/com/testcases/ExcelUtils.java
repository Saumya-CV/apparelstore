package com.testcases;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	
		private static XSSFSheet ExcelWSheet;

		private static XSSFWorkbook ExcelWBook; 

		private static XSSFCell Cell;

		private static XSSFRow Row;



		public static void setExcelFile(String Path) throws Exception {

		try {

		  // Open the Excel file

			FileInputStream ExcelFile = new FileInputStream(Path);

			// Access the required test data sheet

			ExcelWBook = new XSSFWorkbook(ExcelFile);

			//ExcelWSheet = ExcelWBook.getSheet(SheetName);

		} catch (Exception e){

		throw (e);

		}

		}

		public static int getLastRownNo(final String SheetName) {
		    ExcelUtils.ExcelWSheet = ExcelUtils.ExcelWBook.getSheet(SheetName);
		    return ExcelUtils.ExcelWSheet.getLastRowNum();
		}

		public static int getCellIntValue(String SheetName,int RowNum, int ColNum) throws Exception{


		try{

			//Access the required test data sheet

			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			 
			 int CellData = (int) ExcelWSheet.getRow(RowNum).getCell(ColNum).getNumericCellValue();

		  return CellData;
		}
		catch(Exception e)
		{
			 try{
			 if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == CellType.STRING) {
			        return (int) ExcelWSheet.getRow(RowNum).getCell(ColNum).getNumericCellValue();
			    } else if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == CellType.NUMERIC) {
			    	  int value=(int) ExcelWSheet.getRow(RowNum).getCell(ColNum).getNumericCellValue();
			    	 return value;
			    } 
			    else {
			        return ColNum;
			    }
			 }
			 catch(Exception e2)
			 {
				 return ColNum;
			 }
		}

		 


		}

		public static String getCellData(String SheetName,int RowNum, int ColNum) throws Exception{


		try{

			//Access the required test data sheet

			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			 
			 String CellData = ExcelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue().toString();

		  return CellData;
		}
		catch(Exception e)
		{
			 try{
			 if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == CellType.STRING) {
			        return ExcelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();
			    } else if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == CellType.NUMERIC) {
			    	  int value=(int) ExcelWSheet.getRow(RowNum).getCell(ColNum).getNumericCellValue();
			    	 return value+"";
			    } else if (ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == CellType.BOOLEAN) {
			        return ExcelWSheet.getRow(RowNum).getCell(ColNum).getBooleanCellValue() + "";
			    }else if(ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == CellType.BLANK){
			        return ExcelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();
			    }else if(ExcelWSheet.getRow(RowNum).getCell(ColNum).getCellType() == CellType.ERROR){
			        return ExcelWSheet.getRow(RowNum).getCell(ColNum).getErrorCellValue() + "";
			    } 
			    else {
			        return "";
			    }
			 }
			 catch(Exception e2)
			 {
				 return "";
			 }
		}

		 

}
}
