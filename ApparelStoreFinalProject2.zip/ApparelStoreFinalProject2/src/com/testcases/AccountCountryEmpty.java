package com.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class AccountCountryEmpty {
	
	public static WebDriver d1;
	public static ExtentTest test;
	public static ExtentReports report;
	
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
		report = new ExtentReports("./Reports/AccountCountryEmpty.html");
		test = report.startTest("AccountCountryEmpty");
		
				
	}
	//Purpose of Test case :Create an account with the blank country  and verify the same.
	@Test
	public static void createaccount()
	{
		d1.get("http://automationpractice.com/index.php?");
		d1.manage().window().maximize();
		
		d1.findElement(By.xpath("//a[@title='Log in to your customer account']")).click();
		d1.findElement(By.id("email_create")).sendKeys("accounttttt@gmail.com");
		d1.findElement(By.xpath("//button[@class='btn btn-default button button-medium exclusive']")).click();		
		d1.manage().timeouts().implicitlyWait(30000,TimeUnit.MILLISECONDS);
		d1.findElement(By.id("customer_firstname")).sendKeys("Saumya");
		d1.findElement(By.name("customer_lastname")).sendKeys("CV");
		d1.findElement(By.name("passwd")).sendKeys("ABC123");
		d1.findElement(By.name("days")).sendKeys("15");
		d1.findElement(By.name("months")).sendKeys("May");
		d1.findElement(By.name("years")).sendKeys("1990");				
		d1.findElement(By.name("address1")).sendKeys("102 Prosperity house");
		d1.findElement(By.name("city")).sendKeys("Gower");
		d1.findElement(By.name("id_state")).sendKeys("Delaware");
		d1.findElement(By.name("postcode")).sendKeys("38016");
		d1.findElement(By.name("phone_mobile")).sendKeys("1234567890");
		
		d1.findElement(By.xpath("//button[@class='btn btn-default button button-medium']")).click();	
		
		if(d1.getTitle().equals("My account - My Store"))
		{
			test.log(LogStatus.PASS,"Account Creation is Successfully Completed");
		}
		else
		{
			test.log(LogStatus.FAIL, "Test Failed");
		}
		}
		
	@AfterTest
	public static void endTest() {
		report.endTest(test);
		report.flush();
	}
	
	/// Country field kept as blank , however no error popups found

}
