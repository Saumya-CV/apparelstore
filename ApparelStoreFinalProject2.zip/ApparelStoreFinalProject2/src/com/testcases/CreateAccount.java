package com.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class CreateAccount {
	
public static WebDriver d1;
public static ExtentTest test;
public static ExtentReports report;
	
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
		d1.get("http://automationpractice.com/index.php?");
		d1.manage().window().maximize();
		report = new ExtentReports("./Reports/CreateAccount.html");
		test = report.startTest("CreateAccount");
				
	}
	
	//Purpose of Test case :Create an account using values from an Input excel sheet. 
	@Test
	public static void createaccount() throws Exception
	{
		
		
		d1.findElement(By.xpath("//a[@title='Log in to your customer account']")).click();
		
		ExcelUtils.setExcelFile("./Input/TestDataExample2.xlsx");
		String Email = ExcelUtils.getCellData("TestDataExample", 8, 0);
		
		d1.findElement(By.id("email_create")).sendKeys(Email);
		d1.findElement(By.xpath("//button[@class='btn btn-default button button-medium exclusive']")).click();		
		
		d1.manage().timeouts().implicitlyWait(30000,TimeUnit.MILLISECONDS);
		String FName = ExcelUtils.getCellData("TestDataExample", 0, 1);
		d1.findElement(By.id("customer_firstname")).sendKeys(FName);
		String LName = ExcelUtils.getCellData("TestDataExample", 0, 2);
		d1.findElement(By.name("customer_lastname")).sendKeys(LName);
		String Psswd = ExcelUtils.getCellData("TestDataExample", 0, 3);
		d1.findElement(By.name("passwd")).sendKeys(Psswd);
		String Days = ExcelUtils.getCellData("TestDataExample", 0, 4);
		d1.findElement(By.name("days")).sendKeys(Days);
		String Month = ExcelUtils.getCellData("TestDataExample", 0, 5);
		d1.findElement(By.name("months")).sendKeys(Month);
		String Year = ExcelUtils.getCellData("TestDataExample", 0, 6);
		d1.findElement(By.name("years")).sendKeys(Year);	
		String Street = ExcelUtils.getCellData("TestDataExample", 0, 7);		
		d1.findElement(By.name("address1")).sendKeys(Street);
		String City = ExcelUtils.getCellData("TestDataExample", 0, 8);
		d1.findElement(By.name("city")).sendKeys(City);
		String State = ExcelUtils.getCellData("TestDataExample", 0, 9);
		d1.findElement(By.name("id_state")).sendKeys(State);
		String Zip = ExcelUtils.getCellData("TestDataExample", 1, 10);
		d1.findElement(By.name("postcode")).sendKeys(Zip);
		String Country = ExcelUtils.getCellData("TestDataExample", 0, 11);
		d1.findElement(By.name("id_country")).sendKeys(Country);
		String Phone = ExcelUtils.getCellData("TestDataExample", 0, 12);
					
		d1.findElement(By.name("phone_mobile")).sendKeys(Phone);
		
		d1.findElement(By.xpath("//button[@class='btn btn-default button button-medium']")).click();	
		
		if(d1.getTitle().equals("My account - My Store"))
		{
			test.log(LogStatus.PASS,"Account Creation is Successfull");
		}
		else
		{
			test.log(LogStatus.FAIL, "Test Failed");
		}
		}
		
	@AfterTest
	public static void endTest() {
		report.endTest(test);
		report.flush();
	}
	
	

}

//Account creation from Excel sheet succesfully completed
