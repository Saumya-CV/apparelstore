package com.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObjects;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class SignOut {
	
	public static WebDriver d1;
	public static ExtentTest test;
	public static ExtentReports report;
	
	//Purpose of Test case: To test Signout functionality
	
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
		report = new ExtentReports("./Reports/SignOutPage.html");
		test = report.startTest("SignOut");
	}
	
	
	@Test
	public static void LoginValidID() throws Exception
	{
		d1.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		d1.manage().window().maximize();
	
		ExcelUtils.setExcelFile("./Input/TestDataExample2.xlsx");
		String Email = ExcelUtils.getCellData("LoginID", 2, 0);
	
		LoginPageObjects lp = new LoginPageObjects(d1);
		LoginPageObjects.email.sendKeys(Email);
		String Psswd = ExcelUtils.getCellData("LoginID", 2, 1);
		LoginPageObjects.password.sendKeys(Psswd);
		LoginPageObjects.signin.click();
		
		d1.findElement(By.xpath("//a[@title='Log me out']")).click();
		if(d1.getTitle().equals("Login - My Store"))
		{
			test.log(LogStatus.PASS,"Sign Out Successful");
		}
		else
		{
			test.log(LogStatus.FAIL, "Test Failed");
		}
	}
		
		@AfterTest
		public static void endTest() {
			report.endTest(test);
			report.flush();
		
		}	
}