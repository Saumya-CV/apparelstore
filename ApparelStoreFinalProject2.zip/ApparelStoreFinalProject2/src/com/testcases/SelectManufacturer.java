package com.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObjects;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class SelectManufacturer {
	
public static WebDriver d1;
public static ExtentTest test;
public static ExtentReports report;
	
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
	}
	
	//Purpose of Test case :Select a Textile Manufacturer from available manufacturers
	
	@BeforeTest
		public static void LoginValidID() throws Exception
	{
		d1.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		d1.manage().window().maximize();
		report = new ExtentReports("./Reports/SelectManufacturer.html");
		test = report.startTest("SelectManufacturer");
	
		ExcelUtils.setExcelFile("./Input/TestDataExample2.xlsx");
		String Email = ExcelUtils.getCellData("LoginID", 2, 0);
	
		LoginPageObjects lp = new LoginPageObjects(d1);
		LoginPageObjects.email.sendKeys(Email);
		String Psswd = ExcelUtils.getCellData("LoginID", 2, 1);
		LoginPageObjects.password.sendKeys(Psswd);
		LoginPageObjects.signin.click();
	}
	
	@Test
		public static void ManufacturerSelect() {
		d1.findElement(By.id("search_query_top")).sendKeys("Dress");
		d1.findElement(By.xpath("//button[@class='btn btn-default button-search']")).click();
		d1.findElement(By.xpath("//a[normalize-space()='Fashion Manufacturer']")).click();
		
		if(d1.getTitle().equals("Fashion Manufacturer - My Store"))
		{
			test.log(LogStatus.PASS,"Manufacturer Select Successful");
		}
		else
		{
			test.log(LogStatus.FAIL, "Test is Failed");
		}
		
	
	}
	
	
	@Test	
	
	public static void ValidateManufacturerPageTitle()
	{
		String actualpagetitle = d1.getTitle();		
		Assert.assertEquals(actualpagetitle, "Fashion Manufacturer - My Store");
		System.out.println(actualpagetitle);
		
				
	}
	
	@AfterTest
	public static void endTest() {
	report.endTest(test);
	report.flush();
	
		
	}
	
}

//Selection of Manufacturer completed succesfully
