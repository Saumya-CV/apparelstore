package com.testcases;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObjects;

public class InValidLogin {
	
	public static WebDriver d1;
	
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
	}
	
	//Purpose of Test: Test login with invalid credentials from Input Excel
	@Test
	public static void LoginValidID() throws Exception
	{
		d1.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		d1.manage().window().maximize();
		
		ExcelUtils.setExcelFile("./Input/TestDataExample2.xlsx");
		String Email = ExcelUtils.getCellData("LoginID", 0, 0);
	
		LoginPageObjects lp = new LoginPageObjects(d1);
		LoginPageObjects.email.sendKeys(Email);
		String Psswd = ExcelUtils.getCellData("LoginID", 1, 1);
		LoginPageObjects.password.sendKeys(Psswd);
		LoginPageObjects.signin.click();
		
		d1.manage().timeouts().implicitlyWait(1000,TimeUnit.MILLISECONDS);
		
		File screenshot = ((TakesScreenshot)d1).getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(screenshot, new File("./Screenshots/InValidLogin.png"));
			
		System.out.println("Screenshot is captured");
		String title = d1.getTitle();
		FileUtils.copyFile(screenshot, new File("./Screenshots/"+title+".png"));
				
		//Invalid Login test completed successfully
	}
}