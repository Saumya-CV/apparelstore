package com.testcases;


import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObjects;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class PlacingOrder {
	
public static WebDriver d1;
public static ExtentTest test;
public static ExtentReports report;

		
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
		report = new ExtentReports("./Reports/PlaceOrder.html");
		
		test = report.startTest("PlacingOrder");
		
        
	}
	
	@BeforeTest
		public static void LoginValidID() throws Exception
	{
		
		d1.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		d1.manage().window().maximize();
	
		ExcelUtils.setExcelFile("./Input/TestDataExample2.xlsx");
		String Email = ExcelUtils.getCellData("LoginID", 2, 0);
	
		LoginPageObjects lp = new LoginPageObjects(d1);
		LoginPageObjects.email.sendKeys(Email);
		String Psswd = ExcelUtils.getCellData("LoginID", 2, 1);
		LoginPageObjects.password.sendKeys(Psswd);
		LoginPageObjects.signin.click();
		test.log(LogStatus.PASS, "Sucessfully signined");
	}
	
	@Test
	//To test adding 3 items to the cart and placing an order.
	//first item - Blouse
		public static void PlacingOrder() throws IOException {
		
		d1.findElement(By.id("search_query_top")).sendKeys("Blouse");
		d1.findElement(By.xpath("//button[@class='btn btn-default button-search']")).click();
		d1.findElement(By.xpath("//a[@title='Blouse'][normalize-space()='Blouse']")).click();
		d1.findElement(By.xpath("//span[normalize-space()='Add to cart']")).click();
		test.log(LogStatus.PASS, "item added to cart succesfully");
		d1.manage().timeouts().implicitlyWait(30000,TimeUnit.MILLISECONDS);
				
		String parentWindowHandler = d1.getWindowHandle(); 
		String subWindowHandler = null;

		Set<String> handles = d1.getWindowHandles(); 
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();
		}
		d1.findElement(By.xpath("//span[@title='Continue shopping']")).click();
		
		d1.findElement(By.xpath("//img[@alt='My Store']")).click();
	//second item - Chiffon Dress
		d1.findElement(By.id("search_query_top")).sendKeys("Chiffon");
		d1.findElement(By.xpath("//button[@class='btn btn-default button-search']")).click();
		d1.findElement(By.xpath("//a[@title='Printed Chiffon Dress'][normalize-space()='Printed Chiffon Dress']")).click();
		d1.findElement(By.xpath("//span[normalize-space()='Add to cart']")).click();
		test.log(LogStatus.PASS, "item added to cart");
		d1.manage().timeouts().implicitlyWait(30000,TimeUnit.MILLISECONDS);
		d1.findElement(By.xpath("//span[@title='Continue shopping']")).click();
	//third item - T-shirt
		d1.findElement(By.xpath("//img[@alt='My Store']")).click();
		d1.findElement(By.id("search_query_top")).sendKeys("T-shirt");
		d1.findElement(By.xpath("//button[@class='btn btn-default button-search']")).click();
		d1.findElement(By.xpath("//a[@title='Faded Short Sleeve T-shirts'][normalize-space()='Faded Short Sleeve T-shirts']")).click();
		d1.findElement(By.xpath("//span[normalize-space()='Add to cart']")).click();
		test.log(LogStatus.PASS, "item added to cart");
		d1.manage().timeouts().implicitlyWait(30000,TimeUnit.MILLISECONDS);
		d1.findElement(By.xpath("//a[@title='Proceed to checkout']")).click();
	//checkout
		d1.findElement(By.xpath("//a[@class='button btn btn-default standard-checkout button-medium']//span[contains(text(),'Proceed to checkout')]")).click();
		d1.findElement(By.xpath("//button[@name='processAddress']//span[contains(text(),'Proceed to checkout')]")).click();
		WebElement checkbox = d1.findElement(By.xpath("//input[@id='cgv']"));
		checkbox.click();
		d1.findElement(By.xpath("//button[@name='processCarrier']//span[contains(text(),'Proceed to checkout')]")).click();
		d1.findElement(By.xpath("//a[@title='Pay by check.']")).click();
		d1.findElement(By.xpath("//button[@class='button btn btn-default button-medium']")).click();
		test.log(LogStatus.PASS, "order completed");
		
		
		report.endTest(test);
		report.flush();
		
	//screenshot order complete
		File screenshot = ((TakesScreenshot)d1).getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(screenshot, new File("./Screenshots/screenshot.png"));
			
		System.out.println("Screenshot is captured");
		String title = d1.getTitle();
		FileUtils.copyFile(screenshot, new File("./Screenshots/"+title+".png"));
		
	}
	
	
}
