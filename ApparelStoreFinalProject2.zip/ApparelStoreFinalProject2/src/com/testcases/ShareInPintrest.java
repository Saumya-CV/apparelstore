package com.testcases;


import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObjects;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ShareInPintrest {
	
public static WebDriver d1;
public static ExtentTest test;
public static ExtentReports report;

//to test the use of Pinterest and pinning the selected item.
	
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
		report = new ExtentReports("./Reports/ShareInPintrest.html");
		test = report.startTest("ShareInPintrest");
	}
	
	@BeforeTest
		public static void LoginValidID() throws Exception
	{
		d1.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		d1.manage().window().maximize();
	
		ExcelUtils.setExcelFile("./Input/TestDataExample2.xlsx");
		String Email = ExcelUtils.getCellData("LoginID", 2, 0);
	
		LoginPageObjects lp = new LoginPageObjects(d1);
		LoginPageObjects.email.sendKeys(Email);
		String Psswd = ExcelUtils.getCellData("LoginID", 2, 1);
		LoginPageObjects.password.sendKeys(Psswd);
		LoginPageObjects.signin.click();
	}
	
	@Test
		public static void PinIt() {
		d1.findElement(By.id("search_query_top")).sendKeys("Blouse");
		d1.findElement(By.xpath("//button[@class='btn btn-default button-search']")).click();
		d1.findElement(By.xpath("//a[@title='Blouse'][normalize-space()='Blouse']")).click();
		d1.findElement(By.xpath("//button[@class='btn btn-default btn-pinterest']")).click();
		String parentWindowHandler = d1.getWindowHandle(); 
		String subWindowHandler = null;

		Set<String> handles = d1.getWindowHandles(); 
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()){
		    subWindowHandler = iterator.next();
		}
		d1.switchTo().window(subWindowHandler);
		d1.findElement(By.xpath("//input[@id='email']")).sendKeys("saumya@gmail.com");
		d1.findElement(By.name("password")).sendKeys("123abc");
		if(d1.getTitle().equals("Pinterest"))
		{
			test.log(LogStatus.PASS,"Share in Pintrest succesfully completed");
		}
		else
		{
			test.log(LogStatus.FAIL, "Test is Failed");
		}
	}
		
		@AfterTest
		public static void endTest() {
			report.endTest(test);
			report.flush();
				
	}
}