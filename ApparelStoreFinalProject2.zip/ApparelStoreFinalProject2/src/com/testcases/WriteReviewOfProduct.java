package com.testcases;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObjects;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class WriteReviewOfProduct {
	
public static WebDriver d1;
public static ExtentTest test;
public static ExtentReports report;


//Purpose of Test case: Test for Write Review feature
	
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
		report = new ExtentReports("./Reports/WriteReviewOfProduct.html");
		test = report.startTest("WriteReviewOfProduct");
	}
	
	@BeforeTest
		public static void LoginValidID()
	{
		d1.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		d1.manage().window().maximize();
	
		LoginPageObjects lp = new LoginPageObjects(d1);
		LoginPageObjects.email.sendKeys("saumya@gmail.com");
		LoginPageObjects.password.sendKeys("123456");
		LoginPageObjects.signin.click();
	}
	
	@Test
		public static void WriteReview() throws IOException {
		d1.findElement(By.id("search_query_top")).sendKeys("Dress");
		d1.findElement(By.xpath("//button[@class='btn btn-default button-search']")).click();
		d1.findElement(By.xpath("//a[@title='Blouse'][normalize-space()='Blouse']")).click();
		d1.findElement(By.xpath("//a[normalize-space()='Write a review']")).click();
		d1.findElement(By.name("title")).sendKeys("Great Purchase");
		d1.findElement(By.name("content")).sendKeys("Nice Dress");
		d1.findElement(By.xpath("//button[@id='submitNewMessage']//span[contains(text(),'Send')]")).click();
		File screenshot = ((TakesScreenshot)d1).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshot, new File("./Screenshots/screenshot.png"));
		System.out.println("Screenshot is captured");
		String title = d1.getTitle();
		FileUtils.copyFile(screenshot, new File("./Screenshots/"+title+".png"));
		
		if(d1.findElement(By.xpath("//div[@class='fancybox-inner']")) !=null){
			test.log(LogStatus.PASS, "Review Completed");
		}
		
		else {
			test.log(LogStatus.FAIL, "Test Case Failed");
		}
	}
		
	@AfterTest
	public static void endTest() {
		report.endTest(test);
		report.flush();
	}
	}
	
	
	//Test for Product review completed successfully
	
	
	

