package com.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.pageobjects.LoginPageObjects;

public class SearchFunction {
	
public static WebDriver d1;
	
	@BeforeTest
	public static void LaunchBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./BrowserUtils/chromedriver.exe");
		d1 = new ChromeDriver();
	}
	
	@BeforeTest
		public static void LoginValidID() throws Exception
	{
		d1.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		d1.manage().window().maximize();
	
		ExcelUtils.setExcelFile("./Input/TestDataExample2.xlsx");
		String Email = ExcelUtils.getCellData("LoginID", 2, 0);
	
		LoginPageObjects lp = new LoginPageObjects(d1);
		LoginPageObjects.email.sendKeys(Email);
		String Psswd = ExcelUtils.getCellData("LoginID", 2, 1);
		LoginPageObjects.password.sendKeys(Psswd);
		LoginPageObjects.signin.click();
	}
	
	@Test
		public static void SearchFunction() {
		
		d1.findElement(By.id("search_query_top")).sendKeys("Dress");
		d1.findElement(By.xpath("//button[@class='btn btn-default button-search']")).click();
	}
		//search function returns results for dress
	@Test
		public static void ValidateSearchResult() {
		
		String result = d1.findElement(By.xpath("//span[@class='heading-counter']")).getText();
		System.out.println(result);
			
		
	}
		

}
